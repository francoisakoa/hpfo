# Création du dossier hpfo sur la TRX

Ce kit crée un **nouveau** `/data/projects/PF_GlobalOptimization/hpfo` depuis :

- `HPFO_PF131_REVIEW_f97xexav` : préparation déjà validée ;
- `EXPORT_BASELINES_COMPACT_20261010T141633Z_y3yzr2g9` : export des 1 200 baselines ;
- `results_baselines_nohup_R1/results_index.json` : index existant.

```bash
python3 create_hpfo.py
```

Les chemins peuvent être fournis explicitement avec `--stage`, `--baselines-dir`,
`--baselines-index`, `--destination`. Aucun fichier source ou de campagne n'est
modifié. Un `hpfo` déjà présent provoque un refus, jamais un écrasement.

L'installation vérifie puis copie les deux archives PF131 et les ZIP baselines,
importe les sources archivées des baselines, vérifie les 40 cellules de 30 runs,
reconstruit les tableaux et prépare les notices en anglais pour les reviewers.
Elle conserve un seul dossier `release-assets/` avec un manifeste commun sans perdre
les empreintes d'origine. Les gros fichiers sont exclus de Git.

Les schémas des baselines sont vérifiés à la lecture : un schéma non reconnu ou
une version source ambiguë n'est pas remplacé par une supposition. Le diagnostic
est conservé dans `.hpfo-preparation-*/.local/BASELINES_IMPORT_DIAGNOSTIC.json`.

Après assemblage :

```bash
cd /data/projects/PF_GlobalOptimization/hpfo
python3 scripts/verify_package.py --assets
source "$(conda info --base)/etc/profile.d/conda.sh"
conda activate pf_cpp_110
python3 scripts/build_and_test.py --jobs 4 --native
python3 scripts/verify_package.py --for-publish
```

Ces tests peuvent exécuter de petits problèmes unitaires/intégration. Ils ne
relancent pas les campagnes de benchmark. La publication reste une action séparée,
explicite, documentée dans `docs/PUBLICATION_FR.md`.

Aucune compilation des sources C++ de production sur la TRX, aucune importation
du nouveau ZIP du 10 octobre ni aucune publication distante ne doit être déclarée
faite avant le retour effectif des commandes locales correspondantes.
