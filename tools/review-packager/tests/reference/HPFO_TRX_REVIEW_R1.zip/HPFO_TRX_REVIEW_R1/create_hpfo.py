#!/usr/bin/env python3
"""Create a NEW hpfo directory from existing, completed local exports.
No optimizer, network operation, Git commit, or repository publication is run.
"""
from __future__ import annotations
import argparse, collections, csv, json, os, re, shutil, sys, tempfile, zipfile
from datetime import datetime, timezone
from pathlib import Path
KIT=Path(__file__).resolve().parent
sys.path.insert(0,str(KIT/'payload/scripts'))
from hpfo_common import *

TEXT_EXT={'.py','.sh','.cpp','.cc','.c','.h','.hpp','.hxx','.cmake','.json','.csv','.md','.rst',
          '.txt','.yaml','.yml','.toml','.ini','.cfg','.in','.cff','.pfpop','.xyz','.ipynb','.f','.f90'}
NO_DIR={'.git','.venv','venv','__pycache__','node_modules','site-packages','CMakeFiles'}
SECRET=re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |OPENSSH |EC )?PRIVATE KEY-----)')

def baseline_import(zips, destination, index_path, assets, provenance):
    scratch=destination/'.local/baseline-unpack';scratch.mkdir(parents=True)
    for z in zips:extract_zip(z,scratch)
    # Source bundles may be nested. Expand these into a separate, path-traceable tree.
    nested=[]
    for depth in range(3):
        candidates=[p for p in scratch.rglob('*') if p.is_file() and
                    (p.name.endswith(('.tar.gz','.tgz','.tar','.zip'))) and p not in nested]
        if not candidates:break
        for p in candidates:
            require(p.stat().st_size<150*1024**2,'Unexpectedly large nested source archive: '+str(p))
            nested.append(p);out=p.parent/(p.name+'.contents')
            if p.suffix=='.zip':extract_zip(p,out,max_bytes=1024**3)
            else:extract_tar(p,out,max_bytes=1024**3)
    parsed={};known_hashes=hashes_in(load(index_path));json_errors=[]
    for p in sorted(scratch.rglob('*.json')):
        require(p.stat().st_size<128*1024**2,'Unexpectedly large JSON: '+str(p))
        try:j=load(p)
        except (ValueError,UnicodeError) as e:
            json_errors.append(p.relative_to(scratch).as_posix());continue
        parsed[p]=j
        if any(k in p.name.lower() for k in ('index','manifest','sha256','hash')):
            known_hashes |= hashes_in(j)
    rows=[];result_paths=set();identities=set()
    for p,j in parsed.items():
        r=baseline_record(j)
        if r is None:continue
        key=(r['method'],r['atoms'],r['run'])
        require(key not in identities,'Duplicate baseline result, selection not guessed: '+str(key))
        identities.add(key);result_paths.add(p)
        h=sha(p);r.update(file='baselines-export/'+p.relative_to(scratch).as_posix(),sha256=h,
                         archived_hash_match=h in known_hashes)
        rows.append(r)
    expected={(m,n,r) for m in METHODS for n in ATOMS for r in range(1,31)}
    if identities!=expected:
        diagnostic={'found':len(rows),'missing':sorted(expected-identities),
                    'extra':sorted(identities-expected),'invalid_json':json_errors,
                    'sample_json_keys':[{'file':p.relative_to(scratch).as_posix(),
                                         'keys':list(j)[:35]} for p,j in list(parsed.items())[:10] if isinstance(j,dict)]}
        write_json(destination/'.local/BASELINES_IMPORT_DIAGNOSTIC.json',diagnostic)
        raise RuntimeError('Cannot unambiguously identify the 1200 baseline records. '+
                           'Diagnostic: '+str(destination/'.local/BASELINES_IMPORT_DIAGNOSTIC.json'))
    code=destination/SUBDIR/'code/baselines-export';exclusions=[];copied=[]
    for p in sorted(scratch.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(scratch)
        # Preserve exact content and relative module layout, not reconstructed implementations.
        if p in result_paths or p in nested:continue
        if any(part in NO_DIR or part.startswith('build') for part in rel.parts):
            exclusions.append(rel.as_posix());continue
        allowed=p.suffix.lower() in TEXT_EXT or p.name.lower().startswith(('license','copying','notice')) or p.name in ('Makefile','CMakeLists.txt','.gitignore')
        if not allowed or p.stat().st_size>=40*1024**2:
            exclusions.append(rel.as_posix());continue
        snapshot_copy(p,code/rel);copied.append(rel.as_posix())
    drivers=[p.relative_to(code).as_posix() for p in code.rglob('run_one_baseline.py')]
    budgets=[p.relative_to(code).as_posix() for p in code.rglob('*eval*limit*.json')]
    require(drivers,'Frozen baseline run_one_baseline.py missing from ZIP; refusing a results-only repository')
    require(budgets,'Archived baseline evaluation-budget configuration missing from ZIP')
    rows.sort(key=lambda x:(METHODS.index(x['method']),x['atoms'],x['run']))
    write_json(provenance/'BASELINES_RUN_INDEX.json',rows)
    write_json(provenance/'BASELINES_IMPORT.json',{
        'state':'IMPORTED_GRID_VERIFIED', 'results':len(rows),'cells':40,'runs_per_cell':30,
        'archive_hash_matches':sum(r['archived_hash_match'] for r in rows),
        'note':'Hashes checked when present in exported manifests/index. Export membership is not a new historical execution certificate.',
        'frozen_drivers':drivers,'budget_files':budgets,'source_files_copied':len(copied),
        'excluded_from_git_but_retained_in_zip':exclusions,'invalid_nonresult_json_files':json_errors,
        'baseline_trajectories_complete':False})
    return scratch,rows

def create(args):
    stage=args.stage.resolve();old=stage/'git'/SUBDIR
    target=args.destination.absolute();target.parent.mkdir(parents=True,exist_ok=True)
    require(not target.exists() and not target.is_symlink(),'Destination already exists; it will NOT be overwritten: '+str(target))
    check_manifest(KIT/'KIT_SHA256SUMS.txt')
    print('VERIFICATION_DOSSIER_PREPARE',flush=True)
    rows=check_manifest(old/'SHA256SUMS.txt')
    original_assets=check_manifest(stage/'release-assets/SHA256SUMS.txt')
    require({name for _,name in original_assets}=={'hpfo-pf131-main-data.tar.gz','hpfo-pf131-study-data.tar.gz'},
            'Unexpected staged release assets; use the original verified preparation')
    index=load(old/'provenance/RUN_INDEX.json')
    require(collections.Counter(r['dataset'] for r in index)=={'main':240,'ipopt_multistart':240,'study':820},'Unexpected PF index counts')
    br=args.baselines_dir.resolve();checks=check_manifest(br/'SHA256SUMS.txt')
    zips=[br/n for h,n in checks if re.fullmatch(r'BASELINES_COMPACT_\d+\.zip',Path(n).name)]
    require(zips,'No verified BASELINES_COMPACT ZIP in export')
    live_index=args.baselines_index.resolve();require(live_index.is_file(),'Baseline index missing: '+str(live_index))
    free=shutil.disk_usage(target.parent).free
    needed=sum((stage/'release-assets'/n).stat().st_size for h,n in original_assets)+sum(p.stat().st_size for p in zips)+2*1024**3
    require(free>needed,'Insufficient free space: needs roughly '+str(round(needed/1024**3,1))+' GiB')
    work=Path(tempfile.mkdtemp(prefix='.hpfo-preparation-',dir=str(target.parent)))
    print('PREPARATION_TEMPORAIRE='+str(work),flush=True)
    try:
        package=work/SUBDIR;package.mkdir(parents=True)
        for h,name in rows:snapshot_copy(in_root(old,name),package/name)
        snapshot_copy(old/'SHA256SUMS.txt',package/'provenance/UPSTREAM_SHA256SUMS.txt')
        (package/'provenance/UPSTREAM_PREPARATION.json').write_bytes((package/'provenance/PREPARATION.json').read_bytes())
        # Keep the two large PF data archives byte-identical; no recompression.
        assets=work/'release-assets';assets.mkdir()
        for h,name in original_assets:
            print('COPIE_ARCHIVE='+name,flush=True);snapshot_copy(stage/'release-assets'/name,assets/name)
        for p in zips:snapshot_copy(p,assets/p.name)
        provenance=package/'provenance'
        snapshot_copy(br/'SHA256SUMS.txt',provenance/'BASELINES_EXPORT_SHA256SUMS.txt')
        snapshot_copy(live_index,provenance/'BASELINES_ORIGINAL_RESULTS_INDEX.json')
        scratch,baseline_rows=baseline_import(zips,work,live_index,assets,provenance)
        for p in sorted((KIT/'payload').rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:snapshot_copy(p,work/p.relative_to(KIT/'payload'))
        snapshot_copy(package/'CITATION.cff',work/'CITATION.cff')
        # Publish the assembler and its synthetic tests as well, not only the generated tree.
        for digest,name in manifest_read(KIT/'KIT_SHA256SUMS.txt'):
            snapshot_copy(KIT/name,work/'tools/review-packager'/name)
        snapshot_copy(KIT/'KIT_SHA256SUMS.txt',work/'tools/review-packager/KIT_SHA256SUMS.txt')
        prep=load(package/'provenance/PREPARATION.json')
        prep.update(repository='francoisakoa/hpfo',local_directory_created_utc=datetime.now(timezone.utc).isoformat(),
                    baseline_import=load(provenance/'BASELINES_IMPORT.json'),
                    indexed_results={'main':240,'ipopt_multistart':240,'study':820,'external_baselines':1200},
                    publication_state='LOCAL_ASSEMBLY_COMPLETE_BUILD_AND_AUTHOR_REVIEW_REQUIRED',
                    optimization_executed=False,cpp_build_executed=False)
        write_json(provenance/'PREPARATION.json',prep)
        source_files=[]
        for r,p in managed_files(work):
            if '/code/' in '/'+r and p.suffix in {'.c','.cc','.cpp','.h','.hpp','.py','.cmake'} or p.name=='CMakeLists.txt':
                source_files.append({'path':r,'sha256':sha(p)})
        write_json(provenance/'SOURCE_INVENTORY.json',source_files)
        # Supplemental plots/scripts are not silently identified as manuscript figures.
        write_json(provenance/'FIGURE_SCOPE.json',{'diagnostic_script':'scripts/plot_history.py',
                   'exact_manuscript_figures_reproduced_by_this_installer':False,
                   'note':'Original source snapshots are retained. Diagnostic plots are not substitutes for the paper figure-generation pipeline.'})
        asset_rows=[{'name':p.name,'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(assets.iterdir()) if p.is_file()]
        write_json(provenance/'RELEASE_ASSETS.json',asset_rows)
        sums=''.join(r['sha256']+'  '+r['name']+'\n' for r in asset_rows)
        (assets/'SHA256SUMS.txt').write_text(sums)
        (provenance/'RELEASE_SHA256SUMS.txt').write_text(sums)
        # Recompute summaries from actual local JSONs, not the printed report.
        sys.path.insert(0,str(work/'scripts'))
        import rebuild_all
        rebuild_all.rebuild(work,stage/'raw/data',scratch,work/'.local/rebuilt')
        for t in (7,8,9,10):
            require((work/'.local/rebuilt'/f'TABLE_{t}.csv').read_bytes()==(package/'tables'/f'TABLE_{t}.csv').read_bytes(),
                    'Staged Table '+str(t)+' differs from raw-data reconstruction')
        for name in ('MAIN_SUMMARY.csv','IPOPT_MULTISTART_SUMMARY.csv','BASELINES_SUMMARY.csv','BASELINES_RUNS.csv','BASELINES_SUMMARY.md'):
            snapshot_copy(work/'.local/rebuilt'/name,package/'tables'/name)
        # A limited token/key screen: do not claim that this is a full privacy audit.
        for r,p in managed_files(work):
            require(p.stat().st_size<50*1024**2,'File too large for planned Git content: '+r)
            if p.stat().st_size<16*1024**2: require(not SECRET.search(p.read_bytes()),'Potential secret detected in '+r)
        for r in baseline_rows:
            p=scratch/Path(r['file']).relative_to('baselines-export')
            require(not SECRET.search(p.read_bytes()),'Potential secret in a baseline record')
        write_json(provenance/'ASSEMBLY_CHECKS.json',{
            'upstream_git_checksums':'PASS','upstream_release_checksums':'PASS','baseline_zip_checksums':'PASS',
            'pf_json_hashes_and_counters':'PASS','study_table_rebuild':'PASS',
            'baseline_grid':'1200/1200','baseline_source_drivers':'PRESENT',
            'binary_rebuild':'NOT_RUN','full_privacy_and_license_review':'AUTHOR_REQUIRED',
            'raw_data_changed':False,'remote_publication':False})
        # Restore a valid per-component manifest after adding baseline material.
        component_files=[p for p in sorted(package.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
        (package/'SHA256SUMS.txt').write_text(''.join(sha(p)+'  '+p.relative_to(package).as_posix()+'\n' for p in component_files))
        seal(work);check_package(work,assets=True)
        # No source/data directory is deleted. Temporary unpack/rebuild stays local and ignored.
        require(not target.exists(),'Destination appeared during preparation')
        work.rename(target)
        print('HPFO='+str(target))
        print('FICHIERS_GIT='+str(len(load(target/'PACKAGE_MANIFEST.json')['files'])))
        print('RESULTATS_PF=240 ; IPOPT_MULTISTART=240 ; ETUDE=820 ; BASELINES=1200')
        print('ASSEMBLAGE_LOCAL=OK ; TABLEAUX_RECONSTRUITS=OK ; SOURCES_BASELINES=PRESENTES')
        print('COMPILATION_CPP=NON_LANCEE ; PUBLICATION=NON ; AUCUNE_CAMPAGNE_RELANCEE')
    except BaseException:
        print('PREPARATION_INCOMPLETE_CONSERVEE='+str(work),file=sys.stderr)
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    base=Path('/data/projects/PF_GlobalOptimization')
    p.add_argument('--stage',type=Path,default=base/'HPFO_PF131_REVIEW_f97xexav')
    p.add_argument('--baselines-dir',type=Path,default=base/'EXPORT_BASELINES_COMPACT_20261010T141633Z_y3yzr2g9')
    p.add_argument('--baselines-index',type=Path,default=base/'results_baselines_nohup_R1/results_index.json')
    p.add_argument('--destination',type=Path,default=base/'hpfo')
    try:create(p.parse_args())
    except Exception as e:sys.exit('ERREUR: '+str(e))
